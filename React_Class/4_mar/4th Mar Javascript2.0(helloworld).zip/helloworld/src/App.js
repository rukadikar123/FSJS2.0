import React, { useState } from "react";
function App() {
  const [count, setCount] = useState(0);
  const incrementCount = () => {
    setCount(count + 1);
  };
  const decreemtnCount = () => {
    setCount(count - 1);
  };

  return (
    <div className="counter">
      <h1>Counter App</h1>
      <div>{count} </div>
      <div className="button">
        <button onClick={incrementCount}>+</button>
        <button onClick={decreemtnCount}>-</button>
      </div>
    </div>
  );
}

export default App;
